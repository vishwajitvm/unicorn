<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class assignproduct extends Model
{
    use HasFactory;
    // protected $casts = [
    //     'assign_mainmachin_name' => 'array',
    //     'assign_sub_machin_name' => 'array' ,
    //     'serial_number' => 'array',
    // ] ;
}
